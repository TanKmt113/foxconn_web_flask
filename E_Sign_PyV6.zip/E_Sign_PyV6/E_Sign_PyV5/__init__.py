from unicodedata import name
from flask import Flask, request, redirect, url_for,render_template, session,jsonify,send_file
import pandas as pd
from werkzeug.utils import secure_filename
from models.Load_db import create_connection,select_all_nameFile,select_where_Content,select_condition_nameFile,auto_insert
from models.connect_db import create_connection
from models.check_file_name import check_file
from models.AutoAdd import AddAuto,Upload
from jinja2 import Environment, FileSystemLoader
app=Flask(__name__)

# 
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/Test', methods=['GET','POST'])
def Main():
    conn = create_connection()
    Rows=select_all_nameFile(conn)
    Row_contents=select_where_Content(conn,'1')
    app.config["upload"] = "static/pdf/"
    if request.method == 'POST':
            content = request.files['file_path']
            file_name = secure_filename(content.filename)
            content.save(app.config["upload"] + file_name)
            return render_template('view.html',file_path='static/pdf/'+file_name)
    return render_template('view.html',Rows=Rows,Row_contents=Row_contents)


@app.route('/Create', methods=['GET','POST'])
def signUpUser():
    conn = create_connection()
    Rows=select_all_nameFile(conn)
    if request.method == 'POST':
        
        name_option=request.form['name_option']
        name_input=request.form['name_input']
        if(name_input!=''):
            if check_file(conn,name_input)==False: 
                return "False"
            else:
                T=select_condition_nameFile(conn,name_input)
                auto_insert(conn,T)
                Row_contents=select_where_Content(conn,T)
                return Row_contents
        else:
                id=select_condition_nameFile(conn,name_option)
                Row_contents=select_where_Content(conn,id)
                return render_template('/models/load_content.html',Row_contents=Row_contents,check_data=None)
            
    return render_template('view.html',Rows=Rows)


@app.route('/Auto_add', methods=['GET','POST'])
def Auto_add():
    conn = create_connection()
    if request.method == 'POST':
        action=request.form['action']
        id=request.form['id']
        val=request.form['val']
        if(action=="Add_auto"):

            AddAuto(conn,val,id)
            new_val = id.split("_")
            Row_contents=select_where_Content(conn,new_val[2])

            return Row_contents

        else:
            return "Looi roi"

@app.route('/Upload', methods=['GET','POST'])
def Upload_Excel():
    conn = create_connection()
    if request.method == 'POST':
        action=request.form['action']
        id=request.form['id']
        val=request.form['val']
        if(action=="upload"):

            Upload(conn,val,id)
            new_val = id.split("_")
            Row_contents=select_where_Content(conn,new_val[3])
            return Row_contents

        else:
            return "Loi roi"


if __name__=='__main__':
    app.run(debug=True)

