
$(document).ready(function(){

  
  $(document).on('focusout', 'input.new_ip', function() {

    var id =$(this).attr('id');
    if($('#'+id).val()==""){

          return false
    }
    else{
      
      $.post('/Auto_add', 
      {
          action:"Add_auto",
          val:($('#'+id).val()),
          id:id
      
      },function(ketqua) 
        {
            $("#tbl_1").html(ketqua);
            console.log("Them data thanh cong")
        });
      
    }
      
  });

    
  $(document).on('focusout', 'input.input_so', function() {

    var id =$(this).attr('id');
    if($('#'+id).val()==""){
      
          return false
    }else{
      
      $.post('/Upload', 
      {
          action:"upload",
          val:($('#'+id).val()),
          id:id
      },function(ketqua) 
        {
            $("#tbl_1").html(ketqua);
            console.log("upload thanh cong");
        });
      
    }
      
  });

});

      