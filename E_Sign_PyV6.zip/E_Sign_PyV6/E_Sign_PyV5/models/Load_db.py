
import sqlite3
from sqlite3 import Error
from models.connect_db import create_connection
# from data_processing import data_proces

def data_proces(data):
    if data==None:
        data="/"
    else :
       data=data 
    return data

def select_all_nameFile(conn):
 
    cur = conn.cursor()
    cur.execute("select * from File_Excel")

    rows = cur.fetchall()

    # for row in rows:
    #     print(row[1])
    return rows

def select_condition_nameFile(conn,name):
 
    cur = conn.cursor()
    cur.execute("select * from File_Excel where name_file=?",(name,))

    rows = cur.fetchall()

    for row in rows:
        return row[0]


def auto_insert(conn,id):

    sql_concent=f'INSERT INTO Content_file (id_file_name)  VALUES("{id}");'
    cur = conn.cursor()
    cur.execute(sql_concent)
    conn.commit()
    return True


def select_where_Content(conn,id):
 
    cur = conn.cursor()
    cur.execute("SELECT id_content,BU,Sales_office,Sales_area,Order_Type,Sold_to_party,Ship_to_party,PO_No,PO_Date,Material_Name,Customer_Material_No,Order_Quantity,Unit_price,Amount,Shipping_Type,Stor_Location,Po_item,PQ_NO,Reference,packing_slip,Incoterm,PO_Rev,Remark,Location,id_file_name FROM Content_file INNER JOIN File_Excel ON File_Excel.id_file = Content_file.id_file_name where id_file_name=?",(id,))
    count=0
    # count_auto=len(rows)
    rows = cur.fetchall()
  
    html=''
    for row in rows:

        count=count+1
        html+='<tr>'
        # html+=f'<td><input type="text" class="input_so" disabled value={}></td> '
        # html+=f'<td><input type="text" class="input_so" id="BU_{count}_{row[0]}_{row[24]}" value="{data_proces(row[1])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[2])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[3])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[4])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[5])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[6])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[7])}"></td>'
        html+=f'<td><input type="date" class="input_so" id="" value="{data_proces(row[8])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[9])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[10])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[11])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[12])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[13])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[14])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[15])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[16])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[17])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[18])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[19])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[20])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[21])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[22])}"></td>'
        html+=f'<td><input type="text" class="input_so" id="" value="{data_proces(row[23])}"></td>'
        html+='</tr>'
    count_auto=len(rows)
    for x in range(50-len(rows)):
        count_auto=count_auto+1
        html+='<tr>'
        html+=f'<td><input type="text" disabled value={count_auto}></td> '
        html+=f'<td><input type="text" class="new_ip" id="BU_{count_auto}_{id}"  value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="Sales_office_{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="Sales_area_{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="date" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+=f'<td><input type="text" class="new_ip" id="{count_auto}_{id}" value=""></td>'
        html+='</tr>'
    return rows
        

def main():
   

   
    conn = create_connection()
    
    data=select_where_Content(conn,'28')
    data_xx=[]
    for i in data:
        
        for x in range(24):
                
                data_xx.append(data_proces(i[x]))
        
    print(data)
   
    
if __name__ == '__main__':
    main()