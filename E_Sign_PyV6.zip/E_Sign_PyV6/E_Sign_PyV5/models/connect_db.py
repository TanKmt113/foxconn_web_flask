import sqlite3
from sqlite3 import Error
def create_connection():
    conn = None
    try:
        conn = sqlite3.connect(r'C:\Users\Tancoder\Desktop\Wordspace\foxconn_web_flask-main\E_Sign_PyV5\E_Sign_PyV5\db_esign.db')
    except Error as e:
        print(e)

    return conn

