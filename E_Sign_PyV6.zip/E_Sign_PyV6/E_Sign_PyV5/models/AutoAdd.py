
import sqlite3
from sqlite3 import Error
from models.connect_db import create_connection


def AddAuto(conn,val,id):


    new_val = id.split("_") 
    sql_concent=f"INSERT INTO Content_file (id_file_name,{new_val[0]}) VALUES( {new_val[2]},'{val}');"
    cur = conn.cursor()
    cur.execute(sql_concent)
    conn.commit()
    return True


def Upload(conn,val,id):

    new_val = id.split("_")
    sql_concent=f'UPDATE Content_file SET {new_val[0]} ="{val}" WHERE id_content="{new_val[2]}"'
    cur =conn.cursor()
    cur.execute(sql_concent)
    conn.commit()
    return True


def main():
    T=Upload(create_connection(),"Tan999","BU_1_31_25")
   
    print(T)   


if __name__=='__main__':
    main()