
import sqlite3
from sqlite3 import Error
from models.connect_db import create_connection
# from data_processing import data_proces

def data_proces(data):
    if data==None:
        data="/"
    else :
       data=data 
    return data


# def create_connection(db_file):
#     conn = None
#     try:
#         conn = sqlite3.connect(db_file)
#     except Error as e:
#         print(e)

#     return conn


def select_all_nameFile(conn):
 
    cur = conn.cursor()
    cur.execute("select * from File_Excel")

    rows = cur.fetchall()

    # for row in rows:
    #     print(row[1])
    return rows

def select_condition_nameFile(conn,name):
 
    cur = conn.cursor()
    cur.execute("select * from File_Excel where name_file=?",(name,))

    rows = cur.fetchall()

    for row in rows:
        return row[0]


def auto_insert(conn,id):

    sql_concent=f'INSERT INTO Content_file (id_file_name)  VALUES("{id}");'
    cur = conn.cursor()
    cur.execute(sql_concent)
    conn.commit()
    return True


def select_where_Content(conn,id):
 
    cur = conn.cursor()
    cur.execute("SELECT BU,Sales_office,Order_Type,Stor_Location  FROM Content_file INNER JOIN File_Excel ON File_Excel.id_file = Content_file.id_file_name where id_file_name=?",(id,))
    count=0
    rows = cur.fetchall()
    
    html=''
    for row in rows:
        count=count+1
        html+='<tr>'
        html+=f'<td><input type="text" disabled value={count}></td> '
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="date" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+='</tr>'
    return html
        

def main():
   

    # create a database connection
    conn = create_connection()
    auto_insert(conn,'24')
    

if __name__ == '__main__':
    main()