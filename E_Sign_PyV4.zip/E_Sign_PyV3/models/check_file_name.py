
from pickle import TRUE
import sqlite3
from sqlite3 import Error
from sys import flags
from models.connect_db import create_connection
import datetime

x = datetime.datetime.now()


def check_file(conn,name):
    cur = conn.cursor()
    cur.execute("select * from File_Excel where name_file=?",(name,))

    rows = cur.fetchall()
    if len(rows)>0:
        return False
    else:
        cur = conn.cursor()
        sql='INSERT INTO File_Excel (name_file,Create_data) VALUES (?,?);'
        pro=(name,x.strftime("%m/%d/%Y"))
        cur = conn.cursor()
        cur.execute(sql,pro)
        conn.commit() 
        # cur.execute("select * from File_Excel where name_file=?",(name,))

        return True
def main():
    
    T=check_file(create_connection(),'A')
    print(T)

if __name__=='__main__':
    main()


