
$(document).ready(function() {
 
   $('#btn_submit').click(function(e) {
       e.preventDefault();
       if($('#select_file').val()!='' && $('#name_file').val()!='')
       {
         
          alert("Vui lòng không chọn 2 mục !!!");
          return false
       }else if($('#select_file').val()=='' && $('#name_file').val()=='')
       {
          alert("Vui lòng chọn 1 file có sẵn hoặc tạo file mới");
          return false

       }else if($('#select_file').val()!='')
       {
          
           alert("Chọn file "+$('#select_file').val()+" thành công !");
           var y =document.getElementById("new_name_file");
           var x = document.getElementById("main_create");
             if (x.style.display === "block") {
               x.style.display = "block";
             } else {
               x.style.display = "block";
               
             }
             if (y.style.display === "block") {
               y.style.display = "none";
             } 
       }
      
       $.post('/Create', {
           name_input:$('#name_file').val(),
           name_option:$('#select_file').val()
          
       },function(ketqua) {
          var y =document.getElementById("new_name_file");
          var x = document.getElementById("main_create");
           if(ketqua=="False"){
              
                y.style.display = "block";
                x.style.display = "none";
                alert("Tên file đã được sử dụng vui lòng đổi tên file khác !");
           }else{
              if($('#name_file').val()!='')
              {
                alert("Tạo file mới thành công !");
              }
               x.style.display = "block";
               y.style.display = "none";
               $("#tbl_1").html(ketqua);
               
           }
               
       });
       
   });
});