import sqlite3
from sqlite3 import Error
import json
import requests
import datetime
from models.check_file_name import *
from models.connect_db import *
from models.Load_db import *
import json


def get_mail():
    id_order=Select_Order_new(create_connection())
    list_mail=select_where_mail(create_connection(),id_order)
    mail=[]
    for i in list_mail:
        if i[1]!=None:
            mail.append(i[1])
        else :
            pass
    return mail

def get_file_excel():
    id_order=Select_Order_new(create_connection())
    taFile=get_file(create_connection(),id_order)
    lits=[('BU','Sales_office','Sales_area','Order_Type','Sold_to_party','Ship_to_party','PO_No','PO_Date','Material_Name','Customer_Material_No','Order_Quantity','Amount','Shipping_Type','Stor_Location','Po_item','PQ_NO','Reference','packing_slip','Incoterm','PO_Rev','Remark','Location')]
    for i in taFile:
        lits.append(i)
    return lits

def SEND():
    name_order=select_id_order(create_connection())
    url = "http://10.220.40.75:5000/api/create_order"
    payload = json.dumps({
    "username": "V1036302",
    "order_id": f"{name_order}",
    "list_to_mail": get_mail(),
    "order_title": "Application form SO",
    "description": "SO",
    "taFile": json.dumps(get_file_excel()),
    "file_name": f"{name_order}.xlsx",
    "file_type": "Sign_excel"
    })

    headers = {
    'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)







