

from random import random
from random import randrange
import sqlite3
from sqlite3 import Error
from sys import flags
from  models.connect_db import create_connection
import datetime



def Order_new(conn):
        x = datetime.datetime.now()
        t=randrange(100, 1000, 3)
        cur = conn.cursor()
        sql=f"INSERT INTO [Order] (name_order,Create_data,id_user) VALUES ('{'SO'+'_'+x.strftime('%m%d%Y%H%M%S')+str(t)}','{x.strftime('%m/%d/%Y')}','1');"
        cur = conn.cursor()
        cur.execute(sql)
        conn.commit() 
        return True

def Select_Order_new(conn):

    cur = conn.cursor()
    cur.execute("SELECT *FROM [Order] ORDER BY id_order DESC LIMIT 1")
    rows = cur.fetchall()
    for row in rows:
        return row[0]


def select_id_order(conn):

    cur = conn.cursor()
    cur.execute("SELECT *FROM [Order] ORDER BY id_order DESC LIMIT 1")
    rows = cur.fetchall()
    for row in rows:
        return row[1]     



