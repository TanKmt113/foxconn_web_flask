import urllib.request
from bs4 import BeautifulSoup
import sqlite3
from sqlite3 import Error
from  models.connect_db import create_connection
from  models.check_file_name import Select_Order_new
def data_proces(data): 
    if data==None:
        data="/"
    elif data=="":
        data="/"
    else :
       data=data 
    return data

def select_all_nameFile(conn):
    cur = conn.cursor()
    cur.execute("select * from [Order]")
    rows = cur.fetchall()
    return rows

def select_condition_nameFile(conn,name_order):
 
    cur = conn.cursor()
    cur.execute("select * from [Order] where name_order=?",(name_order,))
    rows = cur.fetchall()
    for row in rows:
        return row[0]

def auto_insert(conn,id):

    sql_concent=f'INSERT INTO Content_file (id_order)  VALUES("{id}");'
    cur = conn.cursor()
    cur.execute(sql_concent)
    conn.commit()
    return True


def select_where_Content(conn,id):
 
    cur = conn.cursor()
    cur.execute(f"SELECT id_content,BU,Sales_office,Sales_area,Order_Type,Sold_to_party,Ship_to_party,PO_No,PO_Date,Material_Name,Customer_Material_No,Order_Quantity,Unit_price,Amount,Shipping_Type,Stor_Location,Po_item,PQ_NO,Reference,packing_slip,Incoterm,PO_Rev,Remark,Location,Content_file.id_order FROM Content_file INNER JOIN [Order] ON [Order].id_order = Content_file.id_order where Content_file.id_order='{id}'")
    rows = cur.fetchall()
    return rows



def get_file(conn,id):
 
    cur = conn.cursor()
    cur.execute(f"Select BU,Sales_office,Sales_area,Order_Type,Sold_to_party,Ship_to_party,PO_No,PO_Date,Material_Name,Customer_Material_No,Order_Quantity,Amount,Shipping_Type,Stor_Location,Po_item,PQ_NO,Reference,packing_slip,Incoterm,PO_Rev,Remark,Location FROM Content_file INNER JOIN [Order] ON [Order].id_order = Content_file.id_order where Content_file.id_order='{id}'")
    rows = cur.fetchall()
    return rows

def select_user(conn,name):

    cur = conn.cursor()
    sql=f"SELECT * FROM user INNER JOIN [Order] ON user.id_user = [Order].id_user and [Order].id_order='{Select_Order_new(conn)}' and user.user_name='{name}'"
    cur.execute(sql)
    rows = cur.fetchall()
    return rows

def select_where_Content_one_row(conn,id):
 
    cur = conn.cursor()
    cur.execute("SELECT * FROM Content_file where id_content=?",(id,))
    rows = cur.fetchall()
    return rows
def select_where_mail(conn,id):
 
    cur = conn.cursor()
    cur.execute(f"select * from mail where id_order='{id}'")
    rows = cur.fetchall()
    return rows

def select_where_pdf(conn,id):
 
    cur = conn.cursor()
    cur.execute(f"select * from file_pdf where id_order='{id}'")
    rows = cur.fetchall()
    return rows
def  main():
    
    conn=create_connection()
    T=select_where_pdf(conn,382)
    print(T)

if __name__=='__main__':
    main()