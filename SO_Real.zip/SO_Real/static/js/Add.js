
$(document).ready(function () {
  $(document).on('focusout', 'input.input_so', function () {
    var id = $(this).attr('id');
    if ($('#' + id).val() == "") {
      return false
    } else {
      $.post('/Upload',
        {
          action: "upload",
          val: ($('#' + id).val()),
          id: id
        }, function (ketqua) {
        console.log(ketqua);
      });
    }
  });

  function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-zA-Z0-9_\.\-]+\.)+([a-zA-Z0-9_\.\-])+\@(mail.foxconn.com)+$/;
    return pattern.test(emailAddress);
  };
  $(document).on('focusout', 'input.mail', function () {
    console.log("OKOK")
    var id = $(this).attr('id');
    var y = document.getElementById("error_mail");
    if ($('#' + id).val()==''){
      y.style.color = "red";
      $("#error_mail").html("empty email !");
    }
    else if (!isValidEmailAddress($('#' + id).val())) {
      y.style.color = "red";
      $("#error_mail").html("'"+$('#' + id).val()+"'"+" email format is incorrect !");

    } else {
      $.post('/Upload/Mail',
        {
          action: "upload_mail",
          val: ($('#' + id).val()),
          id: id
        }, function (ketqua) {
        y.style.color = "#25D366";
        $("#error_mail").html("'"+$('#' + id).val()+"'"+" email added successfully!");
      });
    }


  });

  $(document).on('keypress', 'input.input_so', function (e) {
    if (e.keyCode == 13) {
      textboxes = $("input.input_so");
      currentBoxNumber = textboxes.index(this);
      if (textboxes[currentBoxNumber + 1] != null) {
        nextBox = textboxes[currentBoxNumber + 1];
        nextBox.focus();
        nextBox.select();
      }
    }


  });


  $(document).on('keydown.autocomplete', "input.input_so", function () {
    var arr_value = [];

    id = $(this).attr("id").split("-")[0];
    console.log(id)
    $('*[id*=' + id + ']:visible').each(function () {
      if ($(this).val()) {
        arr_value.push($(this).val());
      }
    });
    $(this).autocomplete({ source: arr_value });
  });


  $(document).on('input:checkbox', function () {
    // var id = $(this).attr('id');
    console.log("okok")
  });


  $('#btn_submit').click(function (e) {
    $.confirm({
      title: 'Do you want to create an application ?',
      content: '',
      buttons: {

        cancel: function () {
          $.alert('Canceled!')
        },
        somethingElse: {
          text: 'OK',
          btnClass: 'btn-blue',
          keys: ['enter'],

          action: function () {
            $.post('/Create', {
              action: "new_order"

            }, function (ketqua) {
              var x = document.getElementById("main_create");
                x.style.display = "block";
                $("#main_create").html(ketqua);
            });

          }
        }
      }

    });
  });

});


