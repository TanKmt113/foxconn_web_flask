
// filedata =(document.getElementById('path_pdf').value);
// // PDFObject.embed("static/pdf/sample.pdf", "#pdfwindow");
// // PDFObject.embed("data/V1008647/PDF/sample.pdf", "#pdfwindow");

// function checkFile(){
//     if(filedata==''){
//         console.log("Not");
//     }
//     else{
//         PDFObject.embed(filedata, "#pdfwindow");
//     }
// }

function open_div(){
  var x = document.getElementById("input_excel");
  var y = document.getElementById("div_step");
    if (x.style.display === "block") {

      x.style.display = "none";
      y.style.display = "";
    } else {
      x.style.display = "block";
      y.style.display = "none";
    }
}
function open_colse(){
  var y = document.getElementById("input_excel");
  var x = document.getElementById("div_step");
    if (x.style.display === "block") {

      x.style.display = "none";
      y.style.display = "";
    } else {
      x.style.display = "block";
      y.style.display = "none";
    }
}

function open_div_create(id){
 
}
function close_app(id){
    var x = document.getElementById(id);
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
}


function get_id(id){
 
  sessionStorage.setItem('id_content',id);

  console.log(sessionStorage.getItem('id_content'));
}


function copy_row(id,id_tr,stt){

  $.post('/Copy_row', {
    action: "Copy",
    id_source:sessionStorage.getItem('id_content'),
    id_target:id,
    stt:stt
  }, function (ketqua) {
    console.log("#"+id_tr)
    $("#"+id_tr).html(ketqua);
  });
}

