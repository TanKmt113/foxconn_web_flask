
$(document).ready(function () {

  $('#inputGroupFileAddon01').click(function() {
    var form_data = new FormData($('#upload-file')[0]);
      if (document.getElementById('inputGroupFile01').value != "") {
        if (document.getElementById('inputGroupFile01').value.split('.')[1] == 'pdf') {
            $.ajax({
              type: 'POST',
              url: '/upload/pdf',
              data: form_data,
              contentType: false,
              cache: false,
              processData: false,
              success: function(data) {

                alert("Upload file is successful !!!");
                $("#file").val('')
                $("#list_pdf").html(data);
                
              },
            });
        } else {
            alert("Please upload file with extension is \".pdf\"");
        }
        } else {
            alert('Please choose file to upload');
        } 
});



  $('#save_file').click(function (e) {

    $.post('/Save', {
      action: "Save"

    }, function (ketqua) {
      console.log(ketqua)
      if (ketqua == "True") {
        alert("Đã lưu thành công !")
      } else {
        alert("Lưu không thành công !")
      }

    });

  });

  $('#send_api').click(function (e) {

    $.post('/Send_SO', {
      action: "send_api"

    }, function (ketqua) {
      console.log(ketqua)
      if (ketqua =="True") {
        alert("Sent successfully!")
      } else {
        alert("Sending failed !")
      }
    });
  });

  $('#View').click(function (e) {

    $.post('/View', {
      action: "View"

    }, function (ketqua) {
      $("#tbl_view").html(ketqua);
      console.log(ketqua)
      $("#tbl_view1").html(ketqua);
    });

  });
});