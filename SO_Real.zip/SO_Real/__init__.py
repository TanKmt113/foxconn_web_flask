import os
from unicodedata import name
from flask import Flask, request, redirect, url_for,render_template, session,jsonify,send_file
import pandas as pd
from werkzeug.utils import secure_filename
from models.Load_db import *
from models.connect_db import create_connection
from models.check_file_name import Order_new,Select_Order_new
from models.AutoAdd import *
from flask_session import Session
import json
import requests
from models.send_api_so import SEND
from werkzeug.utils import secure_filename
app=Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
username ="V1036303"


@app.route('/')
def index():
    return render_template('index.html')



@app.route('/Create', methods=['GET','POST'])
def signUpUser():
    conn = create_connection()
    Order_row=select_all_nameFile(conn)
    id_order_old=Select_Order_new(conn)
    select_user(conn,'dotrongtan')
    if request.method == 'POST':
        action=request.form['action']
        if action=="new_order":
           
            Order_new(conn)
            id_order=Select_Order_new(conn)
            
            mails=select_where_mail(conn,id_order)
            cout_mail=len(mails)
            AddMailAuto(conn,cout_mail,id_order)

            Row_contents=select_where_Content(conn,id_order)

            cout_row=len(Row_contents)
            AddAuto(conn,cout_row,id_order)

            after_add=select_where_Content(conn,id_order)
            row_user=select_user(conn,'dotrongtan')
            list_content=[("BU","Sales_office","Sales_area","Order_Type","Sold_to_party","Ship_to_party","PO_No","PO_Date","Material_Name","Customer_Material_No","Order_Quantity","Unit_price","Amount","Shipping_Type","Stor_Location","Po_item","PQ_NO","Reference","packing_slip","Incoterm","PO_Rev","Remark","Location")]
            return render_template('/models/load_content.html',Row_contents=after_add,check_data=None,list_content=list_content,id_name_file=id,check="Create",row_user=row_user,Order_row=Order_row,user=select_user(conn,'dotrongtan'),mails=select_where_mail(conn,id_order))
           
    return render_template('view.html',pdf=select_where_pdf(conn,id_order_old),Order_row=Order_row)

@app.route('/upload/pdf', methods=['GET','POST'])
def UploadPdf():
    conn = create_connection()
    id_order=Select_Order_new(conn)
    if request.method == 'POST':

        file_val = request.files['file']

        uploads_dir = os.path.join(f"static/data/{username.upper()}/PDF")
        os.makedirs(uploads_dir, exist_ok=True)

        file_name = secure_filename(file_val.filename)
        file_val.save(f"static/data/{username.upper()}/PDF/" + file_name)
        path=f"static/data/{username.upper()}/PDF/" + file_name
        Add_pdf(conn,id_order,file_name,path)
        return render_template('/models/load_file_pdf.html',pdf=select_where_pdf(conn,id_order))
    

@app.route('/Upload', methods=['GET','POST'])
def Upload_Excel():
    conn = create_connection()
    if request.method == 'POST':
        action=request.form['action']
        id=request.form['id']
        val=request.form['val']
        if(action=="upload"):

            Upload(conn,val,id)
            return 'update  ok'
        else:
            return "update not ok"

@app.route('/Upload/Mail', methods=['GET','POST'])
def Upload_Mail():
    conn = create_connection()
    if request.method == 'POST':
        action=request.form['action']
        id=request.form['id']
        val=request.form['val']
        id_order=Select_Order_new(conn)
        if(action=="upload_mail"):

            UploadMail(conn,val,id,id_order )
            return id
        else:
            return "update not ok"



@app.route('/View', methods=['GET','POST'])
def View_file():
    conn = create_connection()
    Rows=select_all_nameFile(conn)
    action=request.form['action']
    if(action=="View"):
        id=Select_Order_new(conn)
        # Save(conn)
       
        Row_contents=select_where_Content(conn,id)
       
        return render_template('/models/view.html',Row_contents=Row_contents,check_data="None")
    return render_template('view.html',Rows=Rows)

@app.route('/Copy_row', methods=['GET','POST'])
def CopyRow():
    conn = create_connection()
    action=request.form['action']
    id_source=request.form['id_source']
    id_target=request.form['id_target']
    stt=request.form['stt']
    list_content=[("BU","Sales_office","Sales_area","Order_Type","Sold_to_party","Ship_to_party","PO_No","PO_Date","Material_Name","Customer_Material_No","Order_Quantity","Unit_price","Amount","Shipping_Type","Stor_Location","Po_item","PQ_NO","Reference","packing_slip","Incoterm","PO_Rev","Remark","Location")]

    if(action=="Copy"):
        Copy_row(conn,id_source,id_target)
        Row_contents=select_where_Content_one_row(conn,id_target)
        return render_template('/models/copy_content.html',Row_contents=Row_contents,check_data="None",list_content=list_content,check="Copy",stt=stt)

@app.route('/Send_SO',methods=['GET','POST'])
def Send_SO():
    conn = create_connection()
    if request.method == 'POST':
        action=request.form['action']
        if(action=="send_api"):
            SEND()
            Save(conn)
            return "True"

if __name__=='__main__':
    app.run(debug=True)
  
