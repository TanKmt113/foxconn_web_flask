from flask import Flask, request, redirect, url_for,render_template, session,jsonify,send_file
import pandas as pd
from werkzeug.utils import secure_filename
from models.Load_db import create_connection,select_all_nameFile,select_where_Content
app=Flask(__name__)

# 
@app.route('/')
def index():
    return render_template('index.html')

# @app.route('/ABC',methods=['GET','POST'])
@app.route('/Test', methods=['GET','POST'])
def Main():
   
    # session["file_path"]=None
    database =r"C:\Users\V1036102\Desktop\Project_web_vip\E_Sign_Py\db_esign.db"
    conn = create_connection(database)
    Rows=select_all_nameFile(conn)
    Row_contents=select_where_Content(conn,'1')
    app.config["upload"] = "static/pdf/"
    if request.method == 'POST':
            content = request.files['file_path']

            # uploads_dir = os.path.join(f"data/{username.upper()}/PDF")
            # os.makedirs(uploads_dir, exist_ok=True)
            
            # os.remove(f"data/{username.upper()}/PDF/")
            # objects = os.listdir(uploads_dir)
            # files_file = [f for f in objects if os.path.isfile(os.path.join(uploads_dir, f))]
            # for f in files_file:
            #     os.remove(os.path.join(uploads_dir,f))


            file_name = secure_filename(content.filename)
            # content.save(f"data/{username.upper()}/PDF/" + file_name)
            content.save(app.config["upload"] + file_name)
            
            # file = session["file_path"]=file_name
            data_excel=pd.read_excel(r"C:\Users\V1036102\Desktop\Python Flask\data\V1008647\Excel_Sign\20220722134638253\Fuyu Hiệu chỉnh CCCD.xls")
            data_excel = data_excel.dropna(how='all')
            data_excel = data_excel.fillna("")

            tables=data_excel.to_html(index=False,classes='tbl_excel',table_id='tbl_view')
            return render_template('view.html',file_path='static/pdf/'+file_name,tables=tables)

        

       
    # uploads_dir = os.path.join(f"data/{username.upper()}/PDF/")
    # objects = os.listdir(uploads_dir)
    # files_file = [f for f in objects if os.path.isfile(os.path.join(uploads_dir, f))]
    # for f in files_file:
    #     file_pdf=os.path.join(uploads_dir,f)

    # if(session["file_path"]) : 
    #     file_name='static/pdf/'+session.get("file_path")
    # else:
    #     file_name='static/pdf/sample.pdf'
    data_excel=pd.read_excel(r"C:\Users\V1036102\Desktop\Python Flask\data\V1008647\Excel_Sign\20220722134638253\Fuyu Hiệu chỉnh CCCD.xls")
    data_excel = data_excel.dropna(how='all')
    data_excel = data_excel.fillna("")
    tables=data_excel.to_html(index=False,classes='tbl1',table_id='tbl_view')
    return render_template('view.html',tables=tables,Rows=Rows,Row_contents=Row_contents)


@app.route('/Create', methods=['GET','POST'])
def signUpUser():
    database =r"C:\Users\V1036102\Desktop\Project_web_vip\E_Sign_Py\db_esign.db"
    conn = create_connection(database)
    Rows=select_all_nameFile(conn)
    Row_contents=select_where_Content(conn,2)
    if request.method == 'POST':
        
        id_file=request.form['id_file']
        Row_contents=select_where_Content(conn,id_file)
        return Row_contents
    return render_template('view.html',Row_contents=Row_contents,Rows=Rows)

if __name__=='__main__':
    app.run(debug=True)

