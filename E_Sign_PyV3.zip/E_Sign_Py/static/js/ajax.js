// $(document).ready(function(){
    
//     $("#btn_submit").click(function(){
//         console.log("Test _ok k")
//     // clicked = $(this).attr("name");
//     $.ajax({
//       type : 'post',
//       url: '/Create',
//       data:$('form').serialize(),
//     });
//  });
// });

// // $(function(){
// // 	$('#btn_submit').click(function(){
// //         var name = $('#name_file').val();
// // 		$.ajax({
// // 			url: '/Create',
// // 			data:$('form').serialize(),
// // 			type: 'POST',
// // 			// success: function(response){
// // 			// 	console.log(response);
// // 			// },
// // 			error: function(error){
// // 				console.log(error);
// // 			}
// // 		});
// // 	});
// // });

$(document).ready(function() {
    // var e = document.getElementById("");
    $('#btn_submit').click(function(e) {
        e.preventDefault();
        $.post('/Create', {
            id_file:$('#select_file').val()
           
        },function(ketqua) {
            $('#tbl_1').html(ketqua);
            console.log($('#select_file').val())
        });
        
    });
});