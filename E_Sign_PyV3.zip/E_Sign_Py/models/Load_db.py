from itertools import count
import sqlite3
from sqlite3 import Error
# from data_processing import data_proces

def data_proces(data):
    if data==None:
        data="/"
    else :
       data=data 
    return data


def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)

    return conn


def select_all_nameFile(conn):
 
    cur = conn.cursor()
    cur.execute("select * from File_Excel")

    rows = cur.fetchall()

    # for row in rows:
    #     print(row[1])
    return rows

def select_where_Content(conn,id):
 
    cur = conn.cursor()
    cur.execute("SELECT BU,Sales_office,Order_Type,Stor_Location  FROM Content_file INNER JOIN File_Excel ON File_Excel.id_file = Content_file.id_file_name where id_file_name=?",(id,))
    count=0
    rows = cur.fetchall()
    
    html=''
    for row in rows:
        count=count+1
        html+='<tr>'
        html+=f'<td><input type="text" disabled value={count}></td> '
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'
        html+=f'<td><input type="text" value="{data_proces(row[0])}"></td>'

        html+='</tr>'
    return html
        


# def select_task_by_priority(conn, priority,id):

#     cur = conn.cursor()
#     cur.execute("select * from File_Excel where name_file=? and id_file=?", (priority,id))

#     rows = cur.fetchall()

#     for row in rows:
#         print(row[1])


def main():
    database =r"C:\Users\V1036102\Desktop\Project_web_vip\E_Sign_Py\db_esign.db"

    # create a database connection
    conn = create_connection(database)
    with conn:
       
      
        row=select_where_Content(conn,1)
        # for i in row:
        #     row.index(i)
        #     print(row.index(i))

      


if __name__ == '__main__':
    main()