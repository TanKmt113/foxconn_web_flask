
from unicodedata import name
from flask import Flask, request, redirect, url_for,render_template, session,jsonify,send_file
import pandas as pd
from werkzeug.utils import secure_filename
from models.Load_db import select_where_Content_one_row,create_connection,select_all_nameFile,select_where_Content,select_condition_nameFile,select_user
from models.connect_db import create_connection
from models.check_file_name import Order_new,Select_Order_new
from models.AutoAdd import AddAuto,Upload,Save,Copy_row,UploadMail
from flask_session import Session
import json
import requests
app=Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/Test', methods=['GET','POST'])
def Main():
    conn = create_connection()
    Rows=select_all_nameFile(conn)
    Row_contents=select_where_Content(conn,'1')
    app.config["upload"] = "static/pdf/"
    if request.method == 'POST':
            content = request.files['file_path']
            file_name = secure_filename(content.filename)
            content.save(app.config["upload"] + file_name)
            return render_template('view.html',file_path='static/pdf/'+file_name)
    return render_template('view.html',Rows=Rows,Row_contents=Row_contents)


# @app.route('/Create')
# def home():
   
#     return render_template('view.html')

@app.route('/Create', methods=['GET','POST'])
def signUpUser():
    conn = create_connection()
    Order_row=select_all_nameFile(conn)
    select_user(conn,'dotrongtan')
    if request.method == 'POST':
        action=request.form['action']
        if action=="new_order":
            Order_new(conn)
            id=Select_Order_new(conn)
            Row_contents=select_where_Content(conn,id)
            cout_row=len(Row_contents)
            AddAuto(conn,cout_row,id)
            after_add=select_where_Content(conn,id)
            row_user=select_user(conn,'dotrongtan')
            list_content=[("BU","Sales_office","Sales_area","Order_Type","Sold_to_party","Ship_to_party","PO_No","PO_Date","Material_Name","Customer_Material_No","Order_Quantity","Unit_price","Amount","Shipping_Type","Stor_Location","Po_item","PQ_NO","Reference","packing_slip","Incoterm","PO_Rev","Remark","Location")]
            return render_template('/models/load_content.html',Row_contents=after_add,check_data=None,list_content=list_content,id_name_file=id,check="Create",row_user=row_user,Order_row=Order_row,user=select_user(conn,'dotrongtan'))
           
    return render_template('view.html')


@app.route('/Upload', methods=['GET','POST'])
def Upload_Excel():
    conn = create_connection()
    if request.method == 'POST':
        action=request.form['action']
        id=request.form['id']
        val=request.form['val']
        if(action=="upload"):

            Upload(conn,val,id)
            return 'update  ok'
        else:
            return "update not ok"

@app.route('/Upload/Mail', methods=['GET','POST'])
def Upload_Mail():
    conn = create_connection()
    if request.method == 'POST':
        action=request.form['action']
        id=request.form['id']
        val=request.form['val']
        if(action=="upload_mail"):

            UploadMail(conn,val,id)
            return id
        else:
            return "update not ok"


# @app.route('/Save', methods=['GET','POST'])
# def Save_file():
#     conn = create_connection()
#     if request.method == 'POST':
#         action=request.form['action']
    
#         if(action=="Save"):
#             Save(conn)
#             return "True"
#         else:
#             return 'False'


@app.route('/View', methods=['GET','POST'])
def View_file():
    conn = create_connection()
    Rows=select_all_nameFile(conn)
    name_input=''
    action=request.form['action']
    if(action=="View"):
        id=Select_Order_new(conn)
        Save(conn)
        Row_contents=select_where_Content(conn,id)
        return render_template('/models/view.html',Row_contents=Row_contents,check_data=None)
    return render_template('view.html',Rows=Rows)

@app.route('/Copy_row', methods=['GET','POST'])
def CopyRow():
    conn = create_connection()
    action=request.form['action']
    id_source=request.form['id_source']
    id_target=request.form['id_target']
    stt=request.form['stt']
    list_content=[("BU","Sales_office","Sales_area","Order_Type","Sold_to_party","Ship_to_party","PO_No","PO_Date","Material_Name","Customer_Material_No","Order_Quantity","Unit_price","Amount","Shipping_Type","Stor_Location","Po_item","PQ_NO","Reference","packing_slip","Incoterm","PO_Rev","Remark","Location")]

    if(action=="Copy"):
        Copy_row(conn,id_source,id_target)
        Row_contents=select_where_Content_one_row(conn,id_target)
        return render_template('/models/load_content.html',Row_contents=Row_contents,check_data=None,list_content=list_content,check="Copy",stt=stt)

@app.route('/Send_SO')
def Send_SO():

    url = "http://10.220.40.75:5000/api/create_order"
    payload = json.dumps({
    "username": "V1008647",
    "order_id": "ma dau don",
    "list_to_mail": "patrick.yy.tao@mail.foxconn.com",
    "order_title": "aaaaaa",
    "description": "aaaaaaaacccccc",
    "taFile": "noi dung file sau khi chuyen thanh json",
    "file_name": "",
    "file_type": ""
    })
    headers = {
    'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)

    print(response.text)

if __name__=='__main__':
    app.run(debug=True)
  
