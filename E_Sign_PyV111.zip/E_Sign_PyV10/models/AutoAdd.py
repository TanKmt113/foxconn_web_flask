
from datetime import datetime
from re import T
import sqlite3
from sqlite3 import Error
from models.connect_db import create_connection

def data_proces(data):
    if data==None:
        data=" "
    else :
       data=data 
    return data
def AddAuto(conn,cout_row,id):
    for x in range(50-cout_row):
        sql_concent=f"INSERT INTO Content_file (id_file_name) VALUES( {id});"
        cur = conn.cursor()
        cur.execute(sql_concent)
        conn.commit()
    return True


def UploadMail(conn,val,id):

    new_val = id.split("-")
    sql_concent=f'UPDATE mail SET [e-mail]="{val}"  where id_mail={new_val[1]}'
    cur =conn.cursor()
    cur.execute(sql_concent)
    conn.commit()
    return True

def Upload(conn,val,id):
    new_val = id.split("-")
    sql_concent=f'UPDATE Content_file SET {new_val[0]} ="{val}" WHERE id_content="{new_val[1]}"'
    cur =conn.cursor()
    cur.execute(sql_concent)
    conn.commit()
    return True
def Copy_row(conn,id_source,id_target):
    cur = conn.cursor()
    cur.execute(f'select * from Content_file where id_content={id_source}')
    rows = cur.fetchall()

    list_content=[("id_content","BU","Sales_office","Sales_area","Order_Type","Sold_to_party","Ship_to_party","PO_No","PO_Date","Material_Name","Customer_Material_No","Order_Quantity","Unit_price","Amount","Shipping_Type","Stor_Location","Po_item","PQ_NO","Reference","packing_slip","Incoterm","PO_Rev","Remark","Location","id_file_name")]
    for row in rows:
        for list in list_content:

            for x in range(23):
                sql_concent=f'UPDATE Content_file SET {list[x+1]} ="{data_proces(row[x+1])}" WHERE id_content="{id_target}"'
                cur_1 =conn.cursor()
                cur_1.execute(sql_concent)
                conn.commit()
    return True
    

def Save(conn):

    sql_concent='''
                DELETE FROM Content_file 
                WHERE 
                BU IS NULL and Sales_office IS NULL 
                and Sales_area IS NULL 
                and Order_Type IS NULL 
                and Sold_to_party IS NULL 
                and Ship_to_party IS NULL 
                and PO_No IS NULL 
                and PO_Date IS NULL 
                and Material_Name IS NULL 
                and Customer_Material_No  IS NULL 
                and Order_Quantity  IS NULL 
                and Unit_price IS NULL 
                and Amount IS NULL 
                and Shipping_Type IS NULL 
                and Stor_Location IS NULL 
                and Po_item IS NULL 
                and PQ_No IS NULL 
                and Reference IS NULL 
                and packing_slip IS NULL 
                and Incoterm IS NULL 
                and PO_Rev IS NULL 
                and Remark IS NULL 
                and Location IS NULL 
    '''
    cur =conn.cursor()
    cur.execute(sql_concent)
    conn.commit()
    return True
def main():

    T=Copy_row(create_connection(),'2857','3194')
     
    print(T)
   

if __name__=='__main__':
    main()



