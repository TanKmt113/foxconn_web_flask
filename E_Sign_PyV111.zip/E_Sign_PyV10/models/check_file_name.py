
from pickle import TRUE
import sqlite3
from sqlite3 import Error
from sys import flags
from models.connect_db import create_connection
import datetime
x = datetime.datetime.now()
def Order_new(conn):
        cur = conn.cursor()
        sql=f"INSERT INTO File_Excel (name_file,Create_data,id_order) VALUES ('{'SO'+'_'+x.strftime('%m%d%Y%H%M%S')}','{x.strftime('%m/%d/%Y')}','1');"
        cur = conn.cursor()
        cur.execute(sql)
        conn.commit() 
       
        return True

def Select_Order_new(conn):

    cur = conn.cursor()
    cur.execute("SELECT *FROM File_Excel ORDER BY id_file DESC LIMIT 1;")
    rows = cur.fetchall()
    for row in rows:
        return row[0]


Order_new(create_connection())
