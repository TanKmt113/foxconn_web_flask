import sqlite3
from sqlite3 import Error
from connect_db import create_connection
import json
import requests
import datetime

x = datetime.datetime.now()

# def SEND():
#     url = "http://10.220.40.75:5000/api/create_order"
#     payload = json.dumps({
#     "username": "V1008647",
#     "order_id": "ma dau don",
#     "list_to_mail": "patrick.yy.tao@mail.foxconn.com",
#     "order_title": "aaaaaa",
#     "description": "aaaaaaaacccccc",
#     "taFile": "noi dung file sau khi chuyen thanh json",
#     "file_name": "",
#     "file_type": ""
#     })

#     headers = {
#     'Content-Type': 'application/json'
#     }
#     response = requests.request("POST", url, headers=headers, data=payload,verify=False)
#     print(response.text)

print()