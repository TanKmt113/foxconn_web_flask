
$(document).ready(function () {

  $('#btn_submit').click(function (e) {
    $.post('/Create', {
      action:"new_order"

    }, function (ketqua) {
      var y = document.getElementById("new_name_file");
      var x = document.getElementById("main_create");
      var z = document.getElementById("content_view");
      if (ketqua == "False") {

        y.style.display = "block";
        x.style.display = "none";

        alert("Tên file đã được sử dụng vui lòng đổi tên file khác !");
      } else {
        if ($('#name_file').val() != '') {
          alert("Tạo file mới thành công !");
        }
        x.style.display = "block";
        y.style.display = "none";
        z.style.display = "none";
       
        $("#main_create").html(ketqua);
        
        
      }

    });

  });

  $('#save_file').click(function (e) {

    $.post('/Save', {
      action: "Save"

    }, function (ketqua) {
      console.log(ketqua)
      if (ketqua == "True") {
        alert("Đã lưa thành công !")
      } else {
        alert("Lưa không thành công !")
      }

    });

  });

  $('#View').click(function (e) {

    $.post('/View', {
      action: "View"

    }, function (ketqua) {
      $("#tbl_view").html(ketqua);
      console.log(ketqua)
      $("#tbl_view1").html(ketqua);
    });

  });

  
});