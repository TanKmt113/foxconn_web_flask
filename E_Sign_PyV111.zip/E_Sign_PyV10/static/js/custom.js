
// filedata =(document.getElementById('file_path').value);
// PDFObject.embed("static/pdf/sample.pdf", "#pdfwindow");
// PDFObject.embed("data/V1008647/PDF/sample.pdf", "#pdfwindow");

function checkFile(file_path){
    if(file_path==''){
        console.log("Not");
    }
    else{
        PDFObject.embed(file_path, "#pdfwindow");
        PDFObject.embed(file_path, "#pdfwindow1");
    }
}

function open_div(id){
  var x = document.getElementById(id);
    if (x.style.display === "block") {

      x.style.display = "none";
    } else {
      x.style.display = "block";
      
    }
}

function open_div_create(id){
 
}
function close_app(id){
    var x = document.getElementById(id);
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
}

function submitForm() {
    if (document.getElementById('file').value != "") {
        if (document.getElementById('file').value.split('.')[1] == 'pdf') {
            document.getElementById('submit_Form').submit();
            document.getElementById("notifications").style.display = "block";
           
        } else {
            alert("Please upload file with extension is \".pdf\"");
        }
    } else {
        alert('Please choose file to upload');
    }
}
function get_id(id){
 
  sessionStorage.setItem('id_content',id);

  console.log(sessionStorage.getItem('id_content'));
}
function copy_row(id,id_tr,stt){

  $.post('/Copy_row', {
    action: "Copy",
    id_source:sessionStorage.getItem('id_content'),
    id_target:id,
    stt:stt
  }, function (ketqua) {
    console.log("#"+id_tr)
    $("#"+id_tr).html(ketqua);
  });
}

