
$(document).ready(function(){
  $(document).on('focusout', 'input.input_so', function() {
    var id =$(this).attr('id');
    if($('#'+id).val()==""){
          return false
    }else{
      $.post('/Upload', 
      {
          action:"upload",
          val:($('#'+id).val()),
          id:id
      },function(ketqua) 
        {
            // $("#tbl_1").html(ketqua);
            console.log(ketqua);
        });
    }
  });

function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};
  $(document).on('focusout', 'input.mail', function() {
    var id =$(this).attr('id');
    var y = document.getElementById("notication");
    if(!isValidEmailAddress($('#'+id).val())){
          y.style.color = "red";
          $("#notication").html("Mail không đúng định dạng !");
         
    }else{
      $.post('/Upload/Mail', 
      {
          action:"upload_mail",
          val:($('#'+id).val()),
          id:id
      },function(ketqua) 
        {
            // $("#tbl_1").html(ketqua);
            console.log(ketqua);
            y.style.color = "yellow";
            $("#notication").html("Thêm mail thành công !");
        });
    }
      
      
  });

  $(document).on('keypress', 'input.input_so', function(e) {
    if (e.keyCode == 13)
    {
       
  
        textboxes = $("input.input_so");
        currentBoxNumber = textboxes.index(this);
        if (textboxes[currentBoxNumber + 1] != null) {
            nextBox = textboxes[currentBoxNumber + 1];
            nextBox.focus();
            nextBox.select();
        }
    } 

 
});

       
$(document).on('keydown.autocomplete', "input.input_so", function() {
  var arr_value = [];

  id = $(this).attr("id").split("-")[0];
  console.log(id)
  $('*[id*='+id+']:visible').each(function() {
      if($(this).val()){
          arr_value.push($(this).val());
      }
    
  });
  $(this).autocomplete({ source: arr_value});
});

$(document).on('input:checkbox', function() {
  // var id = $(this).attr('id');
  console.log("okok")
});       
  
});


      